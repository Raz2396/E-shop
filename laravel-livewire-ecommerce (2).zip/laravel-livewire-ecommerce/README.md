<h1 align="center">Laravel 8 E-Commerce Website</h1>

## Features

-   <p>Admin & User can login and Registration.</p>
-   <p>Admin & User can change password</p>
-   <p>Admin can add/edit product categories.</p>
-   <p>Admin can add/edit product.</p>
-   <p>Admin can add/edit/inactive slide.</p>
-   <p>Admin can manage home categories.</p>
-   <p>Admin can set product sale setting.</p>
-   <p>Admin can create cupons.</p>
-   <p>Admin can apply cupons.</p>
-   <p>Admin can set coupons expiry date.</p>
-   <p>Admin can show order and order details.</p>
-   <p>Admin can update Order Status.</p>
-   <p>Admin can create settings.</p>
-   <p>Display data on admin dashboard</p>
-   <p>User can search product by product name & product categories.</p>
-   <p>User can sorting product by product newness,product price low to high & high to low.</p>
-   <p>User can filter product by using product price low to high & high to low.</p>
-   <p>User can add product to wishlist.</p>
-   <p>User can remove product from wishlist.</p>
-   <p>User can show all wishlist products.</p>
-   <p>User can move product from wishlist to cart.</p>
-   <p>User can add product save for later.</p>
-   <p>User can remove product from wishlist.</p>
-   <p>User can add product to product Cart.</p>
-   <p>User can remove product from product Cart.</p>
-   <p>User can checkout with cash on delivery by using stripe payment gateway.</p>
-   <p>User can show order and order details.</p>
-   <p>User can order Cancellation.</p>
-   <p>User can review & rating on product.</p>
-   <p>User can contact Authority.</p>
