<div>
    <h1>User/Customer Dasboard</h1>
</div><?php /**PATH C:\xampp\htdocs\laravel-livewire-ecommerce\resources\views/livewire/user/user-dashboard-component.blade.php ENDPATH**/ ?>